# For each dataset: 
# array.keys() are the ids of each item (e.g.: array['armis-dataset_sample1'])


import json

with open('sample_armis_dataset.json', 'r') as f:
  array_armis = json.load(f)

with open('sample_agreement_dataset.json', 'r') as f:
  array_agreement = json.load(f)

with open('sample_hs-brexit_dataset.json', 'r') as f:
  array_hsbrexit = json.load(f)
  
with open('sample_convabuse_dataset.json', 'r') as f:
  array_convabuse= json.load(f)
